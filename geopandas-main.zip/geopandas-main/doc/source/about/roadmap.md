# Roadmap

## Roadmap for GeoPandas 1.0

WIP
