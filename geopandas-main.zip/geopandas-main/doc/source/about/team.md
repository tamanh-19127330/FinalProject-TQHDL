# Team

## Contributors

GeoPandas is developed by more than [100 volunteer contributors](https://github.com/geopandas/geopandas/graphs/contributors).

## Core developers
- Joris Van den Bossche - **lead maintainer** | [@jorisvandenbossche](https://github.com/jorisvandenbossche)
- Martin Fleischmann | [@martinfleis](https://github.com/martinfleis)
- James McBride | [@jdmcbr](https://github.com/jdmcbr)
- Brendan Ward | [@brendan-ward](https://github.com/brendan-ward)
- Levi Wolf | [@ljwolf](https://github.com/ljwolf)

## Founder

- Kelsey Jordahl | [@kjordahl](https://github.com/kjordahl)

## Alumni developers

- Jacob Wasserman | [@jwass](https://github.com/jwass)
