=====
Tools
=====
.. currentmodule:: geopandas

.. autosummary::
   :toctree: api/

   sjoin
   sjoin_nearest
   overlay
   clip
   tools.geocode
   tools.reverse_geocode
   tools.collect
   points_from_xy
   datasets.available
   datasets.get_path
